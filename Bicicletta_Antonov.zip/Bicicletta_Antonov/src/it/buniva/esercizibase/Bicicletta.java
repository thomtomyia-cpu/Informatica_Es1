package it.buniva.esercizibase;

public class Bicicletta extends MezzoDiTrasporto {
    private int marcia;
    private int numeriMarce;

    public Bicicletta(String nome, int anno, double velocitaMassima, int numeriMarce) {
        super(nome, anno, velocitaMassima);
        this.numeriMarce = numeriMarce;
        this.marcia = 1;
    }

    public void cambiaMarcia(int nuovaMarcia) {
        if (nuovaMarcia >= 1 && nuovaMarcia <= this.numeriMarce) {
            this.marcia = nuovaMarcia;
            System.out.println(">>> Cambio in marcia " + this.marcia + " <<<");
        } else {
            System.out.println("Marcia " + nuovaMarcia + " non disponibile");
        }
    }

    public void pedala() {
        if (this.isInMarcia()) {
            System.out.println("Pedalando in marcia " + this.marcia + "...");
        } else {
            System.out.println("Prima sali sulla bicicletta");
        }
    }

    public int getMarcia() {
        return this.marcia;
    }

    public int getNumeriMarce() {
        return this.numeriMarce;
    }
}
