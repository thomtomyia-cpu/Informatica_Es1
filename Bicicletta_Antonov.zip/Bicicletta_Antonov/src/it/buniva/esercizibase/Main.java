package it.buniva.esercizibase;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner ts = new Scanner(System.in);

        System.out.print("Nome del mezzo: ");
        String nome = ts.nextLine();
        System.out.print("Anno di produzione: ");
        int anno = ts.nextInt();
        System.out.print("Velocita massima (km/h): ");
        double velocitaMassima = ts.nextDouble();
        System.out.print("Numero di marce: ");
        int numeriMarce = ts.nextInt();
        System.out.print("Nuova marcia: ");
        int nuovaMarcia = ts.nextInt();

        Bicicletta bici = new Bicicletta(nome, anno, velocitaMassima, numeriMarce);

        bici.mount();
        bici.cambiaMarcia(nuovaMarcia);
        bici.pedala();
        bici.dismount();

        System.out.println("\nStato finale: " + bici.getNome() + " del " + bici.getAnno() + ", velocita massima " + bici.getVelocitaMassima() + " km/h, marcia " + bici.getMarcia() + ", in marcia = " + bici.isInMarcia());
    }
}
