package it.buniva.esercizibase;

public class MezzoDiTrasporto {
    private String nome;
    private int anno;
    private double velocitaMassima;
    private boolean inMarcia;

    public MezzoDiTrasporto(String nome, int anno, double velocitaMassima) {
        this.nome = nome;
        this.anno = anno;
        this.velocitaMassima = velocitaMassima;
        this.inMarcia = false;
    }

    public void mount() {
        if (!this.inMarcia) {
            this.inMarcia = true;
            System.out.println(">>> Sei salito sulla " + this.nome + " <<<");
        }
    }

    public void dismount() {
        if (this.inMarcia) {
            this.inMarcia = false;
            System.out.println(">>> Sei sceso dalla " + this.nome + " <<<");
        }
    }

    public String getNome() {
        return this.nome;
    }

    public int getAnno() {
        return this.anno;
    }

    public double getVelocitaMassima() {
        return this.velocitaMassima;
    }

    public boolean isInMarcia() {
        return this.inMarcia;
    }
}
