package it.buniva.esercizibase;

public class Ascensore extends Montacarichi {
    private int pianoPartenza;
    private int pianoArrivo;
    private int[] pianiPrenotati;
    private int nPrenotati;

    public Ascensore(int pianiTotali, int pianoPartenza, int pianoArrivo, int nPrenotati) {
        super(pianiTotali, pianoPartenza);
        this.pianoPartenza = pianoPartenza;
        this.pianoArrivo = pianoArrivo;
        this.pianiPrenotati = new int[nPrenotati];
        this.nPrenotati = 0;
    }

    public void prenota(int piano) {
        if (piano >= 0 && piano < this.getPianiTotali()) {
            this.pianiPrenotati[this.nPrenotati] = piano;
            this.nPrenotati++;
        }
    }

    public boolean ePrenotato(int piano) {
        for (int i = 0; i < this.getNPrenotati(); i++) {
            if (this.pianiPrenotati[i] == piano) {
                return true;
            }
        }
        return false;
    }

    public void arriva() {
        System.out.println("L'ascensore parte dal piano " + this.getPianoCorrente() + " verso il piano di arrivo " + this.pianoArrivo);
        while (this.getPianoCorrente() != this.pianoArrivo) {
            if (this.getPianoCorrente() < this.pianoArrivo) {
                this.sali();
            } else {
                this.scendi();
            }
            System.out.println("Piano corrente: " + this.getPianoCorrente());
            if (this.ePrenotato(this.getPianoCorrente())) {
                System.out.println(">>> Fermata al piano " + this.getPianoCorrente() + " (piano prenotato) <<<");
                this.apriPorta();
                System.out.println("Porte aperte");
                this.chiudiPorta();
                System.out.println("Porte chiuse");
            }
        }
        this.apriPorta();
        System.out.println("Arrivato al piano di arrivo " + this.pianoArrivo + "! Porte aperte.");
    }

    public int getPianoPartenza() {
        return this.pianoPartenza;
    }

    public int getPianoArrivo() {
        return this.pianoArrivo;
    }

    public int getNPrenotati() {
        return this.nPrenotati;
    }
}
