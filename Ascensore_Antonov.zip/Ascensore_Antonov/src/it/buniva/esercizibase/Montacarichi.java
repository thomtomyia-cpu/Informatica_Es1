package it.buniva.esercizibase;

public class Montacarichi {
    private int pianiTotali;
    private int pianoCorrente;
    private boolean portaAperta;

    public Montacarichi(int pianiTotali, int pianoCorrente) {
        this.pianiTotali = pianiTotali;
        this.pianoCorrente = pianoCorrente;
        this.portaAperta = false;
    }

    public void sali() {
        if (this.pianoCorrente < this.pianiTotali - 1) {
            this.pianoCorrente++;
        }
    }

    public void scendi() {
        if (this.pianoCorrente > 0) {
            this.pianoCorrente--;
        }
    }

    public void apriPorta() {
        this.portaAperta = true;
    }

    public void chiudiPorta() {
        this.portaAperta = false;
    }

    public int getPianiTotali() {
        return this.pianiTotali;
    }

    public int getPianoCorrente() {
        return this.pianoCorrente;
    }

    public boolean isPortaAperta() {
        return this.portaAperta;
    }
}
