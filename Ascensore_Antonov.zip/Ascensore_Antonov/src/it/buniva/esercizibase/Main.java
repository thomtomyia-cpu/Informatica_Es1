package it.buniva.esercizibase;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner ts = new Scanner(System.in);

        System.out.print("Quanti piani ha il palazzo? ");
        int pianiTotali = ts.nextInt();
        System.out.print("Piano di partenza (0 = piano terra): ");
        int pianoPartenza = ts.nextInt();
        System.out.print("Piano di arrivo: ");
        int pianoArrivo = ts.nextInt();
        System.out.print("Quanti piani prenotati? ");
        int nPrenotati = ts.nextInt();

        Ascensore ascensore = new Ascensore(pianiTotali, pianoPartenza, pianoArrivo, nPrenotati);
        for (int i = 0; i < nPrenotati; i++) {
            System.out.print("Piano prenotato " + (i + 1) + ": ");
            ascensore.prenota(ts.nextInt());
        }

        ascensore.arriva();
        System.out.println("\nStato finale: partenza = " + ascensore.getPianoPartenza() + ", piano corrente = " + ascensore.getPianoCorrente() + ", prenotazione = " + ascensore.getNPrenotati() + ", porte aperte = " + ascensore.isPortaAperta());
    }
}
