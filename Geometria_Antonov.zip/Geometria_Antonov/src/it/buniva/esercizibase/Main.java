package it.buniva.esercizibase;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner ts = new Scanner(System.in);

        System.out.print("Lato dell'ottagono: ");
        double lato = ts.nextDouble();
        Ottagono ottagono = new Ottagono(lato);

        System.out.print("Base del rettangolo: ");
        double base = ts.nextDouble();
        System.out.print("Altezza del rettangolo: ");
        double altezza = ts.nextDouble();
        Rettangolo rettangolo = new Rettangolo(base, altezza);

        System.out.print("Lato del quadrato: ");
        double latoQuad = ts.nextDouble();
        Quadrato quadrato = new Quadrato(latoQuad);

        System.out.print("Base del triangolo isoscele: ");
        double baseTri = ts.nextDouble();
        System.out.print("Lato uguale del triangolo isoscele: ");
        double latoUg = ts.nextDouble();
        TriangoloIsoscele triangolo = new TriangoloIsoscele(baseTri, latoUg);

        System.out.println();
        System.out.println("=== FIGURE ===");
        System.out.printf("%s: nLati=%d, area=%.2f, perimetro=%.2f\n", ottagono.getNome(), ottagono.getNLati(), ottagono.calcolaArea(), ottagono.calcolaPerimetro());
        System.out.printf("%s: nLati=%d, area=%.2f, perimetro=%.2f\n", rettangolo.getNome(), rettangolo.getNLati(), rettangolo.calcolaArea(), rettangolo.calcolaPerimetro());
        System.out.printf("%s: nLati=%d, area=%.2f, perimetro=%.2f\n", quadrato.getNome(), quadrato.getNLati(), quadrato.calcolaArea(), quadrato.calcolaPerimetro());
        System.out.printf("%s: nLati=%d, area=%.2f, perimetro=%.2f\n", triangolo.getNome(), triangolo.getNLati(), triangolo.calcolaArea(), triangolo.calcolaPerimetro());

        System.out.println();
        System.out.print("Vuoi fare un confronto? (Si/No): ");
        String risposta = ts.next();

        if (risposta.equalsIgnoreCase("Si")) {
            System.out.println("Figure disponibili: Ottagono, Rettangolo, Quadrato, TriangoloIsoscele");
            System.out.print("Prima figura: ");
            String nome1 = ts.next();
            System.out.print("Seconda figura: ");
            String nome2 = ts.next();
            System.out.print("Cosa vuoi confrontare? (Area/Perimetro): ");
            String cosa = ts.next();

            Poligono f1;
            if (nome1.equals("Ottagono")) {
                f1 = ottagono;
            } else if (nome1.equals("Rettangolo")) {
                f1 = rettangolo;
            } else if (nome1.equals("Quadrato")) {
                f1 = quadrato;
            } else {
                f1 = triangolo;
            }

            Poligono f2;
            if (nome2.equals("Ottagono")) {
                f2 = ottagono;
            } else if (nome2.equals("Rettangolo")) {
                f2 = rettangolo;
            } else if (nome2.equals("Quadrato")) {
                f2 = quadrato;
            } else {
                f2 = triangolo;
            }

            System.out.println();
            System.out.println(f1.confrontaCon(f2, cosa));
        } else {
            System.out.println("Ok, nessun confronto.");
        }
    }
}
