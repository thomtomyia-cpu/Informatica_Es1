package it.buniva.esercizibase;

public class Rettangolo extends Poligono {

    private double base;
    private double altezza;

    public Rettangolo(double base, double altezza) {
        super("Rettangolo", 4);
        this.base = base;
        this.altezza = altezza;
    }

    public double calcolaArea() {
        return base * altezza;
    }

    public double calcolaPerimetro() {
        return 2 * (base + altezza);
    }

    public double getBase() {
        return base;
    }

    public double getAltezza() {
        return altezza;
    }
}
