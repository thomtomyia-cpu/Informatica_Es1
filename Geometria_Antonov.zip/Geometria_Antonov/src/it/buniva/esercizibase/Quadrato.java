package it.buniva.esercizibase;

public class Quadrato extends Rettangolo {

    public Quadrato(double lato) {
        super(lato, lato);
        setNome("Quadrato");
    }
}
