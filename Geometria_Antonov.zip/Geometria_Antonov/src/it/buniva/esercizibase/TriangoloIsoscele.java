package it.buniva.esercizibase;

public class TriangoloIsoscele extends Poligono {

    private double base;
    private double latoUguale;

    public TriangoloIsoscele(double base, double latoUguale) {
        super("TriangoloIsoscele", 3);
        this.base = base;
        this.latoUguale = latoUguale;
    }

    public double calcolaArea() {
        double h = Math.sqrt(latoUguale * latoUguale - (base / 2) * (base / 2));
        return base * h / 2;
    }

    public double calcolaPerimetro() {
        return base + 2 * latoUguale;
    }

    public double getBase() {
        return base;
    }

    public double getLatoUguale() {
        return latoUguale;
    }
}
