package it.buniva.esercizibase;

public class Ottagono extends Poligono {

    private double lato;

    public Ottagono(double lato) {
        super("Ottagono", 8);
        this.lato = lato;
    }

    public double calcolaArea() {
        return 2 * (1 + Math.sqrt(2)) * lato * lato;
    }

    public double calcolaPerimetro() {
        return 8 * lato;
    }

    public double getLato() {
        return lato;
    }
}
