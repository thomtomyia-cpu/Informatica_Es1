package it.buniva.esercizibase;

public class Poligono {

    private String nome;
    private int nLati;

    public Poligono(String nome, int nLati) {
        this.nome = nome;
        this.nLati = nLati;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getNLati() {
        return nLati;
    }

    public double calcolaArea() {
        return 0;
    }

    public double calcolaPerimetro() {
        return 0;
    }

    public String confrontaCon(Poligono altra, String cosa) {
        String r = "Confronto tra " + getNome() + " e " + altra.getNome() + "\n";
        if (cosa.equalsIgnoreCase("Area")) {
            if (calcolaArea() > altra.calcolaArea()) {
                r = r + "Area: " + getNome() + " e' maggiore di " + altra.getNome();
            } else if (calcolaArea() < altra.calcolaArea()) {
                r = r + "Area: " + altra.getNome() + " e' maggiore di " + getNome();
            } else {
                r = r + "Area: le due figure sono uguali";
            }
        } else {
            if (calcolaPerimetro() > altra.calcolaPerimetro()) {
                r = r + "Perimetro: " + getNome() + " e' maggiore di " + altra.getNome();
            } else if (calcolaPerimetro() < altra.calcolaPerimetro()) {
                r = r + "Perimetro: " + altra.getNome() + " e' maggiore di " + getNome();
            } else {
                r = r + "Perimetro: le due figure hanno lo stesso valore";
            }
        }
        return r;
    }
}
